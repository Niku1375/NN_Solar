// Simple service worker for offline support and caching
const CACHE_NAME = 'nn-solar-v1';
const urlsToCache = [
  '/',
  '/assets/generated/solar-hero-banner.dim_1200x600.jpg',
  '/assets/generated/nn-enterprises-logo-transparent.dim_200x200.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(urlsToCache))
  );
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request)
      .then((response) => response || fetch(event.request))
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});
